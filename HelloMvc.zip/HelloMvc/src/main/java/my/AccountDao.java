package my;






public interface AccountDao {

//	@Transactional
	void save(Employee e);
	public Employee read(int id);
}
