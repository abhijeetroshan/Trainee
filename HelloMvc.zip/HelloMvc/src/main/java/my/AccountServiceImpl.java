package my;

import javax.validation.Valid;

import org.springframework.validation.BindingResult;

public class AccountServiceImpl implements AccountService{
	AccountDao accountDao;
	
	//CONSTRUCTOR
	public AccountServiceImpl(AccountDao accountDao) {
		super();
		this.accountDao = accountDao;
	}
//	//GETTERS AND SETTERS
//	public AccountDao getAccountDao() {
//		return accountDao;
//	}
//	public void setAccountDao(AccountDao accountDao) {
//		this.accountDao = accountDao;
//	}
	
	//METHODS
	@Override
	public String  newRecord(@Valid Employee e, BindingResult result) {
		if(result.hasErrors()) {
			return "ERROR";
		}
		accountDao.save(e);
		return "SUCCESS";
		
	}

	@Override
	public Employee readTable(int id) {
		// TODO Auto-generated method stub
		Employee e = accountDao.read(id);
		if(e==null)
		{
			throw new ArithmeticException();
		}
		return e;
	}

}
