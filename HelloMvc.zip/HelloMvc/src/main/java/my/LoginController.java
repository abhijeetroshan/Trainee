package my;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	// @PersistenceContext
	// EntityManager em;
	@Autowired
	AccountServiceImpl impl;

	// @RequestMapping(method = RequestMethod.GET, path = "/performactions")
	// public String performActions(@ModelAttribute("e") Employee e) {
	// return "updaterecord";
	//
	// }

	@RequestMapping(method = RequestMethod.GET, path = "/getPage")
	public String sayHello(@ModelAttribute("e") Employee e) {
		return "hello";

	}
	//
	// //
	// @RequestMapping(method = RequestMethod.GET, path = "/new")
	// public String updateNew(@ModelAttribute("e") Employee e) {
	// return "new";
	//
	// }
	
//	 @Transactional
//	 
//	 @RequestMapping(method = RequestMethod.POST, path = "/getrecord") public
//	 ModelAndView newEmployee(@ModelAttribute("e") Employee e) { ModelAndView mv =
//	 new ModelAndView(); mv.setViewName("record"); mv.addObject("key",
//	  e.getEid()); em.persist(e); System.out.println(e.getEid() + " " + e.getAge()
//	  + "  " + e.getName()); return mv;
//	  
//	  }
	 

	@Transactional
	@RequestMapping(method = RequestMethod.POST, path = "/getrecord")
	public ModelAndView newEmployee(@ModelAttribute("e") @Valid Employee e,  BindingResult result) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("hello");
		String name = impl.newRecord(e, result);
		if (result.hasErrors())
			return mv;
		mv.setViewName("record");
		mv.addObject("key",e);
		return mv;

	}

	@Transactional
	@RequestMapping(method = RequestMethod.GET, path = "/read/{id}")
	public ModelAndView readEmployee(@PathVariable("id") int id) {
		/*
		 * Employee e = em.find(Employee.class, id);
		 * 
		 * ModelAndView mv = new ModelAndView(); mv.setViewName("empInfo");
		 * mv.addObject("key", e.getEid()); System.out.println(e.getEid() + " " +
		 * e.getAge() + "  " + e.getName()); return mv;
		 */
		
		Employee e = impl.readTable(id);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("record");
		mv.addObject("key", e);
		System.out.println(e.getAge()+" "+e.getName());
		return mv;
	}

	// @Transactional
	// @RequestMapping(method = RequestMethod.GET, path = "/update/{id}/{name}")
	// public ModelAndView updateEmployee(@PathVariable("id") int id,
	// @PathVariable("name") String name) {
	//
	// Employee e = em.find(Employee.class, id);
	// ModelAndView mv = new ModelAndView();
	// mv.setViewName("updaterecord");
	// mv.addObject("key", e);
	// e.setName(name);
	//// em.merge(e);
	// em.persist(e);
	// return mv;
	// }
	//
	// @Transactional
	// @RequestMapping(method = RequestMethod.GET, path = "/delete/{id}")
	// public ModelAndView deleteEmployee(@PathVariable("id") int id) {
	// Employee e = em.find(Employee.class, id);
	// ModelAndView mv = new ModelAndView();
	// mv.setViewName("remove");
	// mv.addObject("key", e);
	// em.remove(e);
	// return mv;
	// }

	// @Transactional
	// @RequestMapping(method = RequestMethod.POST, path = "/new/{id}/{name}")
	// public ModelAndView updateEmployee(@PathVariable("id") int id,
	// @PathVariable("name") String name) {
	// // Employee emp = em.find(Employee.class,e.getEid());
	// Employee e = em.find(Employee.class, id); // Consider em as JPA EntityManager
	// e.setName(name);
	// em.merge(e);
	// ModelAndView mv = new ModelAndView();
	// mv.setViewName("record");
	// mv.addObject("key", e);
	// return mv;
	// }

}
