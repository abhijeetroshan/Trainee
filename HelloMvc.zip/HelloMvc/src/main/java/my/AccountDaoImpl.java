package my;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.transaction.annotation.Transactional;


public class AccountDaoImpl implements AccountDao{
	@PersistenceContext
	EntityManager em;
	
	@Transactional
	@Override
	public void save(Employee e) {
		// TODO Auto-generated method stub
		em.persist(e);
//		return null;
	}
	@Override
	public Employee read(int id) {
		// TODO Auto-generated method stub
;
		return em.find(Employee.class, id);
	}


}
